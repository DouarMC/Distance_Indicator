import { world, system } from "@minecraft/server";
import * as MINECRAFT_UTILS_FUNCTIONS from "../utilities/minecraft_utills_functions";
// Interval qui affiche dans l'actionbar à chaque joueur sa propre distance entre lui et chacun des autres joueurs
system.runInterval(() => {
    if (world.getDynamicProperty("douarmc:distance_indicator_state") === false)
        return; // Si l'indicateur de distance est désactivé, on ne fait rien
    const players = world.getPlayers({ excludeTags: ["douarmc:hide_distance_indicator"] }); // On récupère tous les joueurs qui n'ont pas le tag "douarmc:hide_distance_indicator"
    for (const player of players) { // Pour chaque joueur
        const playersDistance = MINECRAFT_UTILS_FUNCTIONS.getAllPlayersDistances(player, players); // On récupère la distance entre le joueur et chacun des autres joueurs
        const playersCardinalRelativeDirections = MINECRAFT_UTILS_FUNCTIONS.getAllPlayersCardinalRelativeDirection(player, players); // On récupère la direction cardinale entre le joueur et chacun des autres joueurs
        let distanceTextToDisplay = ""; // On initialise une variable pour stocker le texte à afficher
        for (const playerName in playersDistance) { // Pour chaque joueur
            distanceTextToDisplay += `§a${playerName}§f: ${playersDistance[playerName]}m §e${playersCardinalRelativeDirections[playerName]}§f; `; // On ajoute le nom du joueur, sa distance et sa direction cardinale
        }
        ;
        distanceTextToDisplay.slice(0, -2); // On retire les deux derniers caractères de la chaîne de caractères
        player.onScreenDisplay.setActionBar(distanceTextToDisplay); // On affiche le texte dans l'actionbar du joueur
    }
    ;
});
