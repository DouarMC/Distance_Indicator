import { world, system } from "@minecraft/server";
// Crée une propriété dynamique pour stocker l'état de l'indicateur de distance
system.afterEvents.scriptEventReceive.subscribe((eventData) => {
    const scripteventId = eventData.id;
    switch (scripteventId) { // Vérifie l'ID de l'événement
        case "douarmc:toggle_distance_indicator": // Si l'ID est "douarmc:toggle_distance_indicator"
            const nextDistanceIndicatorState = world.getDynamicProperty("douarmc:distance_indicator_state") === true ? false : true; // Inverse l'état de l'indicateur de distance
            world.setDynamicProperty("douarmc:distance_indicator_state", nextDistanceIndicatorState); // Applique le nouvel état de l'indicateur de distance
            break;
        default:
            return;
    }
    ;
}, { namespaces: ["douarmc"] });
