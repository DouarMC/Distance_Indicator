import { world } from "@minecraft/server";
import * as ALL_EXPORTS from "exports";
if (world.getDynamicProperty("douarmc:distance_indicator_state") === undefined) {
    world.setDynamicProperty("douarmc:distance_indicator_state", true);
}
;
ALL_EXPORTS;
