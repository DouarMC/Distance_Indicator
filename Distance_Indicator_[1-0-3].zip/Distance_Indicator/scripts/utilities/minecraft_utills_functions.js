/**
 * Renvoie la liste de tous les joueurs sauf celui spécifié.
 * @param playerA Le joueur spécifié
 * @param players La liste de tous les joueurs
 * @returns
 */
export function getOtherPlayers(playerA, players) {
    return players.filter((player) => player.id !== playerA.id); // Renvoie la liste de tous les joueurs sauf celui spécifié.
}
;
/**
 * Renvoie la distance en blocs entre deux emplacements.
 * @param locationA L'emplacement A
 * @param locationB L'emplacement B
 * @returns
 */
export function getDistance(locationA, locationB) {
    const { x: x1, y: y1, z: z1 } = locationA; // On récupère les coordonnées x, y et z de l'emplacement A
    const { x: x2, y: y2, z: z2 } = locationB; // On récupère les coordonnées x, y et z de l'emplacement B
    const distance = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2 + (z2 - z1) ** 2); // On calcule la distance entre les deux emplacements
    return Math.floor(distance); // On arrondit la distance à l'entier inférieur
}
;
/**
 * Renvoie la ditance en blocs entre un joueur séléctionné avec chacun des autres joueurs
 * @param player
 * @param players
 * @returns
 */
export function getAllPlayersDistances(player, players) {
    const distances = {}; // On initialise un objet pour stocker les distances
    const otherPlayers = getOtherPlayers(player, players); // On récupère la liste de tous les joueurs sauf celui spécifié
    for (const otherPlayer of otherPlayers) { // Pour chaque joueur
        if (otherPlayer.dimension.id !== player.dimension.id) { // Si le joueur et l'autre joueur ne sont pas dans la même dimension
            distances[otherPlayer.name] = "§cX§f"; // On ajoute le nom du joueur et "X" pour indiquer que le joueur est dans une autre dimension
        }
        else { // Sinon
            distances[otherPlayer.name] = getDistance(player.location, otherPlayer.location); // On ajoute le nom du joueur et sa distance
        }
        ;
    }
    ;
    return distances; // On renvoie l'objet contenant les distances
}
;
/**
 * Renvoie la direction cardinale à partir d'un angle.
 * @param angle L'angle
 * @returns
 */
export function getCardinalDirectionFromAngle(angle) {
    if (angle >= 337.5 || angle < 22.5) { // Si l'angle est compris entre 337.5 et 22.5
        return "N"; // On renvoie "N" pour Nord
    }
    else if (angle >= 22.5 && angle < 67.5) { // Si l'angle est compris entre 22.5 et 67.5
        return "NE"; // On renvoie "NE" pour Nord-Est
    }
    else if (angle >= 67.5 && angle < 112.5) { // Si l'angle est compris entre 67.5 et 112.5
        return "E"; // On renvoie "E" pour Est
    }
    else if (angle >= 112.5 && angle < 157.5) { // Si l'angle est compris entre 112.5 et 157.5
        return "SE"; // On renvoie "SE" pour Sud-Est
    }
    else if (angle >= 157.5 && angle < 202.5) { // Si l'angle est compris entre 157.5 et 202.5
        return "S"; // On renvoie "S" pour Sud
    }
    else if (angle >= 202.5 && angle < 247.5) { // Si l'angle est compris entre 202.5 et 247.5
        return "SW"; // On renvoie "SW" pour Sud-Ouest
    }
    else if (angle >= 247.5 && angle < 292.5) { // Si l'angle est compris entre 247.5 et 292.5
        return "W"; // On renvoie "W" pour Ouest
    }
    else if (angle >= 292.5 && angle < 337.5) { // Si l'angle est compris entre 292.5 et 337.5
        return "NW"; // On renvoie "NW" pour Nord-Ouest
    }
    ;
}
;
/**
 * Renvoie la direction relative cardinale du joueur B par rapport au joueur A
 * @param playerA Le joueur A
 * @param playerB Le joueur B
 * @returns
 */
export function getPlayersCardinalRelativeDirection(playerA, playerB) {
    const playerA_Location = playerA.location; // On récupère l'emplacement du joueur A
    const playerB_Location = playerB.location; // On récupère l'emplacement du joueur B
    const playerA_ViewDirection = playerA.getViewDirection(); // On récupère la direction de vue du joueur A
    const deltaX = playerB_Location.x - playerA_Location.x; // On calcule la différence de coordonnées x entre les deux joueurs
    const deltaZ = playerB_Location.z - playerA_Location.z; // On calcule la différence de coordonnées z entre les deux joueurs
    const scalarProduct = deltaX * playerA_ViewDirection.x + deltaZ * playerA_ViewDirection.z; // On calcule le produit scalaire entre les deux vecteurs
    const magnitudeA = Math.sqrt(playerA_ViewDirection.x * playerA_ViewDirection.x + playerA_ViewDirection.z * playerA_ViewDirection.z); // On calcule la magnitude du vecteur du joueur A
    const magnitudeDelta = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ); // On calcule la magnitude du vecteur entre les deux joueurs
    const angleRad = Math.acos(scalarProduct / (magnitudeA * magnitudeDelta)); // On calcule l'angle en radians entre les deux vecteurs
    let angleDeg = angleRad * 180 / Math.PI; // On convertit l'angle en degrés
    const crossProduct = playerA_ViewDirection.x * deltaZ - playerA_ViewDirection.z * deltaX; // On calcule le produit vectoriel entre les deux vecteurs
    if (crossProduct < 0) { // Si le produit vectoriel est inférieur à 0
        angleDeg = 360 - angleDeg; // On ajuste l'angle
    }
    ;
    const cardinalRelativeDirection = getCardinalDirectionFromAngle(angleDeg); // On récupère la direction cardinale à partir de l'angle
    return cardinalRelativeDirection; // On renvoie la direction cardinale
}
;
/**
 * Renvoie la direction relative cardinale de chaque joueur par rapport à un joueur spécifié
 * @param player Le joueur spécifié
 * @param players La liste de tous les joueurs
 * @returns
 */
export function getAllPlayersCardinalRelativeDirection(player, players) {
    const playersCardinalRelativeDirection = {}; // On initialise un objet pour stocker les directions cardinales
    const otherPlayers = getOtherPlayers(player, players); // On récupère la liste de tous les joueurs sauf celui spécifié
    for (const otherPlayer of otherPlayers) { // Pour chaque joueur
        if (otherPlayer.dimension.id !== player.dimension.id) { // Si le joueur et l'autre joueur ne sont pas dans la même dimension
            playersCardinalRelativeDirection[otherPlayer.name] = ""; // On ajoute le nom du joueur et "X" pour indiquer que le joueur est dans une autre dimension
        }
        else { // Sinon
            playersCardinalRelativeDirection[otherPlayer.name] = getPlayersCardinalRelativeDirection(player, otherPlayer); // On ajoute le nom du joueur et sa direction cardinale
        }
        ;
    }
    ;
    return playersCardinalRelativeDirection; // On renvoie l'objet contenant les directions cardinales
}
;
